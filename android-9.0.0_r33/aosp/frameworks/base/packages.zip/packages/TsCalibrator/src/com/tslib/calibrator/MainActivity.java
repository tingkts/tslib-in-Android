package com.tslib.calibrator;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.os.SystemProperties;
import android.util.Log;
import android.view.InputDevice;
import android.view.View;
import android.view.Surface;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;
import android.hardware.input.InputManager;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = MainActivity.class.getName();

    private static final String TARGET_FOLDER = "/data/system/tscalibrate";
    private static final String TARGET_FILE = TARGET_FOLDER + "/" + "active_tsdevice";

    private InputManager inputManager;

    private Button btnPerformCalibration;
    private Spinner spinnerTsDevice;
    
    private LinkedHashMap<String, TsInputDevice> tsDeviceMap = new LinkedHashMap<>();    
    private TsInputDevice activeTsDevice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // setup ui button
        btnPerformCalibration = (Button) findViewById(R.id.button);
        btnPerformCalibration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBtnClickTsLibLauncher();
            }
        });

        // translate drawn graphic roatation to physical rotation
        int rotation =  getWindowManager().getDefaultDisplay().getRotation();
        Log.d(TAG, "rotation=" + rotation);
        if (rotation == Surface.ROTATION_90) {
            rotation = Surface.ROTATION_270;
        } else if (rotation == Surface.ROTATION_270) {
            rotation = Surface.ROTATION_90;
        }
        Log.d(TAG, "traslated rotation=" + rotation);

        // enum input device path
        String cmdOutput = cmdExec("dumpsys input | grep Path -B 2 | grep -E \"[0-9]: |Path: \"");
        Log.d(TAG, "" + cmdOutput);
        Log.d(TAG, "\n");
        HashMap<String, String> inputDeviceNamePathMap = parseInputDevicePath(cmdOutput);

        // filter ts device
        inputManager = (InputManager) getSystemService(Context.INPUT_SERVICE);
        int[] deviceId = inputManager.getInputDeviceIds();
        for (int i = 0 ; i < deviceId.length ; i++) {
            InputDevice inputDevice = inputManager.getInputDevice(deviceId[i]);
            if (inputDevice.getSources() == InputDevice.SOURCE_TOUCHSCREEN) {
                String name = inputDevice.getName();
                String path = inputDeviceNamePathMap.get(name);
                Log.d(TAG, "add : " + inputDevice + "path: " + path);
                tsDeviceMap.put(name, new TsInputDevice(inputDevice, path, rotation));
            }
        }

        // if no ts device, exit directly
        if (tsDeviceMap.isEmpty()) {
            showExitDialog();
        } else {
        // setup ui spinner
            spinnerTsDevice = (Spinner) findViewById(R.id.spinner);
            ArrayAdapter<String> tsDeviceSpinnerAdapter = new ArrayAdapter<>(MainActivity.this,
                    android.R.layout.simple_spinner_dropdown_item,
                    tsDeviceMap.keySet().toArray(new String[]{}));
            spinnerTsDevice.setAdapter(tsDeviceSpinnerAdapter);
            spinnerTsDevice.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    onSpinnerItemSelected(position);
                }
                @Override
                public void onNothingSelected(AdapterView<?> parent) {}
            });
            spinnerTsDevice.setSelection(0);
            if (tsDeviceMap.size() == 1) {
                spinnerTsDevice.setEnabled(false);
            }            
        }
    }

    private void onBtnClickTsLibLauncher() {
        Log.d(TAG, "onBtnClickTsLibLauncher");
        SystemProperties.set("ctl.start", "ts_calibrate");
        finish();
    }

    private void onSpinnerItemSelected(int position) {
        Log.d(TAG, "onSpinnerItemSelected: " + position);
        setActiveTsDevice(position);
    }

    private void showExitDialog() {
        AlertDialog errorDialog = new AlertDialog.Builder(this).create();
        errorDialog.setTitle(getString(R.string.exit_dlg_title));
        errorDialog.setMessage(getString(R.string.exit_dlg_content));
        errorDialog.setButton(getString(R.string.exit_dlg_btn), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        errorDialog.setCancelable(false);
        errorDialog.show();        
    }

    private String cmdExec(String ls_cmd) {
        String ls_result = "";
        try{
            String[] ls_cmd_split = {"sh", "-c", ls_cmd};
            Process p = new ProcessBuilder(ls_cmd_split).redirectErrorStream(true).start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String result = "";
            while ((result = br.readLine()) != null) {
                if (!result.trim().equals("")) {
                    if (ls_result.equals("")) {
                        ls_result = result.trim();
                    } else{
                        ls_result = ls_result + "\n" + result.trim();
                    }
                }
            }
        } catch(Exception e) {
            Log.d(TAG, e.getMessage(), new RuntimeException().fillInStackTrace());
        }
        return ls_result;
    }

    private HashMap<String, String> parseInputDevicePath(String dumpInputString) {
        HashMap<String, String> mapNamePath = new HashMap<>();
        String[] lines = dumpInputString.split("\n");
        for (int i = 2 ; i < lines.length ; i += 2) {
            String line1 = lines[i];
            String line2 = lines[i+1];
            Log.d(TAG, line1 + ", " + line2);

            if (i % 2 == 0) {
                String name = line1.substring(3);
                Log.d(TAG, "name: " + name);

                String path = line2.substring(6);
                Log.d(TAG, "path: " + path);

                mapNamePath.put(name, path);
            }
        }
        Log.d(TAG, "\n");
        return mapNamePath;
    }

    private void setActiveTsDevice(int position) {
        TsInputDevice[] tsDevoceArray = tsDeviceMap.values().toArray(new TsInputDevice[]{});
        activeTsDevice = tsDevoceArray[position];
        Log.d(TAG, "setActiveTsDevice: position=" + position + ", " + activeTsDevice);

        // write to file
        try {
            File file = new File(TARGET_FILE);
            file.createNewFile();
            file.setReadable(true, false);
            file.setWritable(true, false);
            FileWriter fw = new FileWriter(file);
            String splitter = ",";
            fw.write(activeTsDevice.getPath() + splitter + activeTsDevice.getRotation() + splitter
                    + activeTsDevice.getInputDevice().getDescriptor() + splitter + activeTsDevice.getInputDevice().getName());
            fw.flush();
            fw.close();

            // write success, enable btn
            btnPerformCalibration.setEnabled(true);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}