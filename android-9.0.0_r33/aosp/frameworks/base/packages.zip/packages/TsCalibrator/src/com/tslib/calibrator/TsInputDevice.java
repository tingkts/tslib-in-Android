package com.tslib.calibrator;

import android.view.InputDevice;

public class TsInputDevice {
    private InputDevice inputDevice;
    private String path;
    private int rotation;

    public TsInputDevice() {}

    public TsInputDevice(InputDevice inputDevice, String path, int rotation) {
        this.inputDevice = inputDevice;
        this.path = path;
        this.rotation = rotation;
    }

    void setInputDevice(InputDevice inputDevice) {
        this.inputDevice = inputDevice;
    }

    void setPath(String path) {
        this.path = path;
    }

    void setRotation(int rotation) {
        this.rotation = rotation;
    }

    InputDevice getInputDevice() {
        return inputDevice;
    }

    String getPath() {
        return path;
    }

    int getRotation() {
        return rotation;
    }

    @Override
    public String toString() {
        return "TsInputDevice@" + this.hashCode() + ": " + inputDevice + ", " + path + ", rotation=" + rotation;
    }    
}
